﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinskTrans
{
	public class Time
	{
		public Time(string str)
		{
			int indexStart = 0;
			char sym = ',';
			TimesDictionary = new List<Dictionary<int, List<int>>>();

			int indexEnd = str.IndexOf(sym);
			RoutId= int.Parse(str.Substring(indexStart, indexEnd));
			int val = 0;
			int hour = 0;
			List<int> listValue = new List<int>();
			var dictionary = new Dictionary<int, List<int>>();
			while (true)
			{
				indexStart = indexEnd + 1;
				indexEnd = str.IndexOf(sym, indexStart);
				if (indexStart == indexEnd)
					break;
				listValue.Add(int.Parse(str.Substring(indexStart, indexEnd-indexStart)));
				val += listValue[listValue.Count - 1];
				hour = val/60;
				int min = (val - hour*60);
				if (!dictionary.ContainsKey(hour))
					dictionary.Add(hour, new List<int>() { { min } });
				else
					dictionary[hour].Add(min);
			}

			TimesDictionary.Add(dictionary);

			var splitStr = str.Split(new []{",,"}, StringSplitOptions.RemoveEmptyEntries);


			int counter = 0;
			int correction = 0;
			for (int i = 4; i < splitStr.Count(); i++)
			{
				TimesDictionary.Add(new Dictionary<int, List<int>>());
				//var split = splitStr[i].Split(',', StringSplitOptions.RemoveEmptyEntries);
				if (counter <= 0)
				{
					//indexEnd = splitStr[i].LastIndexOf(sym, splitStr[i].Count() - 3); //есть другие числа
					//if (indexEnd > 0)
					//{

					//	var tempStr = splitStr[i].Substring(0, splitStr[i].Count() - 2);
					//}
					//else
					//{
					//	correction = int.Parse(splitStr[i].Substring(0, splitStr[i].Count() - 2));
					//}
				}
				counter--;
				//val = 0;
				//dictionary = null;
				//int counter = 0;
				//int correction = 0;
				//for (int j = 0; j < listValue.Count; j++)
				//{
				//	val += listValue[j];
				//	hour = val/60;
				//	int min = (val - hour*60);

				//	if (counter <= 0)
				//	{
				//		indexEnd = splitStr[i].LastIndexOf(sym, splitStr[i].Count() - 3); //есть другие числа
				//		if (indexEnd > 0)
				//		{

				//			var tempStr = splitStr[i].Substring(0, splitStr[i].Count() - 2);
				//		}
				//		else
				//		{
				//			correction = int.Parse(splitStr[i].Substring(0, splitStr[i].Count() - 2));
				//		}
				//	}
				//	counter--;
				//	min += correction;
				//	if (!dictionary.ContainsKey(hour))
				//		dictionary.Add(hour, new List<int>() {{min}});
				//	else
				//		dictionary[hour].Add(min);
				//}
			}
		}
		public int RoutId { get; set; }
		public Rout Rout { get; set; }
		public List<Dictionary<int, List<int>>> TimesDictionary { get; set; } 

	}
}
